// small JS for UX
document.addEventListener('DOMContentLoaded', function(){
  // simple console hint
  console.log('Car Cleanz site ready.');
});
